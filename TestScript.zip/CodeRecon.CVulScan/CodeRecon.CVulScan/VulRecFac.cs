﻿using CodeRecon.Core.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CodeRecon.Core;

namespace CodeRecon.CVulScan
{
    public class VulRecFac : IVulRec
    {
        public string VulID
        {
            get
            {
                throw new NotImplementedException();
            }

            set
            {
                throw new NotImplementedException();
            }
        }

        public List<CRVul> GetVul(List<CRFile> soureFiles)
        {
            try
            {
                List<CRVul> vuls = new List<CRVul>();
                foreach (var f in soureFiles)
                {
                    //call your scanners
                    VUL70277 v70277 = new VUL70277();
                    VUL70221 v70221 = new VUL70221();
                    VUL70363 v70363 = new VUL70363();

                    //get a list of vuls and add them to vuls
                    foreach (var v in v70277.GetVuls(f))
                    {
                        vuls.Add(v);
                    }

                    //get a list of vuls and add them to vuls
                    foreach (var v in v70221.GetVuls(f))
                    {
                        vuls.Add(v);
                    }

                    //get a list of vuls and add them to vuls
                    foreach (var v in v70363.GetVuls(f))
                    {
                        //vuls.Add(v);
                    }

                }

                return vuls;
            }
            catch (Exception ex)
            {
                throw new VulRecFacException(ex.Message);
            }
            
        }
    }
}
