﻿using CodeRecon.Core;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CodeRecon.CVulScan
{
    public class VUL70221
    {
        List<CRVul> vuls;

        public VUL70221()
        {
            _init_vuls();
        }
        public List<CRVul> GetVuls(CRFile file)
        {
            try
            {
                //loop through files looking for catch
                var lines = File.ReadAllLines(file.Path);
                //read all lines and parse by line (inner loop)
                for (int i = 0; i < lines.Length; i++)
                {
                    try
                    {

                        //first check for throws equal to catches
                        bool equalThrowtoCatch = throwstocatchareequal(file.Path);
                        //if not equal flag catches
                        if(!equalThrowtoCatch)
                        {
                            var matches = Regex.Matches(lines[i], @"catch\(");
                            if (matches.Count > 0)
                            {
                                //found match do something
                                CRVul vul = new CRVul();
                                vul.VulID = "VUL70221";
                                vul.Line = lines[i];
                                vul.LineNumber = i;
                                vul.Path = file.Path;
                                //add to list
                                vuls.Add(vul);
                            }
                        }
                        
                        
                    }
                    catch (Exception ex)
                    {
                        throw new VulRecFacException("VUL70277: error parsing lines..." + ex.Message);
                    }
                }
                return vuls;

                   
            }
            catch (Exception ex)
            {
                throw new VulRecFacException("VUL70221: error parsing lines..." + ex.Message);
            }
        }

        private void _init_vuls()
        {
            vuls = new List<CRVul>();
        }

        private bool throwstocatchareequal(string filePath)
        {
            bool areEqual = false;
            var throwmatches = Regex.Matches(File.ReadAllText(filePath), "throw");
            var catchmatches = Regex.Matches(File.ReadAllText(filePath), "catch");
            if(throwmatches == catchmatches)
            {
                areEqual = true;
            }
            return areEqual;
        }
    }
}
