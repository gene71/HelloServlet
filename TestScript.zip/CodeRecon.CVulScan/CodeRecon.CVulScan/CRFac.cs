﻿using CodeRecon.Core.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CodeRecon.Core;
using System.IO;

namespace CodeRecon.CVulScan
{
    public class CRFac : ICRFac
    {
        public List<CRFile> BuildCRFiles(string dir)
        {
            try
            {
                CRFileFactory crffac = new CRFileFactory();
                //this is a c/cpp scan
                List<CRFile> cCRfiles = new List<CRFile>();
                foreach(var f in crffac.BuildCRFiles(dir, true))
                {
                    if(f.Extension == ".cpp" || f.Extension == ".h"
                        || f.Extension == ".hpp" || f.Extension == ".cu")
                    {
                        //process here
                        CodeLineCounter cls = new CodeLineCounter();
                        f.AppComponent = "source";
                        f.ExecLines = cls.GetExecutableLineCount(f.Path);
                        f.Lines = File.ReadAllLines(f.Path).Length;
                        cCRfiles.Add(f);
                    }
                }
                return cCRfiles;
            }
            catch (Exception ex)
            {
                throw new VulRecFacException(ex.Message);
            }
        }
    }
}
