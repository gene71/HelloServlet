﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeRecon.CVulScan
{
    public abstract class CVulScanException : Exception
    {
        public CVulScanException(string message) : base("CVulScanException " + message)
        {

        }
    }
}
