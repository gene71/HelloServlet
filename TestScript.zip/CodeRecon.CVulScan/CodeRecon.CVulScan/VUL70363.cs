﻿using CodeRecon.Core;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CodeRecon.CVulScan
{
    public class VUL70363
    {
        List<string> authData;
        List<CRVul> vuls;

        public VUL70363()
        {
            _init_authData();
            _init_vuls();
        }

        public List<CRVul> GetVuls(CRFile file)
        {
            try
            {
                //loop through authData(outer loop)
                foreach (var ad in authData)
                {
                    var lines = File.ReadAllLines(file.Path);
                    //read all lines and parse by line (inner loop)
                    for (int i = 0; i < lines.Length; i++)
                    {
                        try
                        {
                            var matches = Regex.Matches(lines[i], ad);
                            if (matches.Count > 0)
                            {
                               
                                    //found match do something
                                    CRVul vul = new CRVul();
                                    vul.VulID = "VUL70363";
                                    vul.Line = lines[i];
                                    vul.LineNumber = i;
                                    vul.Path = file.Path;
                                    //add to list
                                    vuls.Add(vul);
                               


                            }
                        }
                        catch (Exception ex)
                        {
                            throw new VulRecFacException("VUL70363: error parsing lines..." + ex.Message);
                        }
                    }//end inner loop

                }//end outer loop
                return vuls;

            }
            catch (Exception ex)
            {
                throw new VulRecFacException("VUL70363..." + ex.Message);
            }//outer catch
        }


        private void _init_vuls()
        {
            vuls = new List<CRVul>();
        }
        private void _init_authData()
        {
            authData = new List<string>();
            authData.Add(@"username");
            authData.Add(@"userName");
            authData.Add(@"UserName");
            authData.Add(@"USERName");
            authData.Add(@"USERNAME");
            authData.Add(@"USER");
            authData.Add(@"user");
            authData.Add(@"usr");
            authData.Add(@"USR");
            authData.Add(@"password");
            authData.Add(@"PASSWORD");
            authData.Add(@"PassWord");
            authData.Add(@"passWord");
            authData.Add(@"pwd");
            
        }
    }

   

}
