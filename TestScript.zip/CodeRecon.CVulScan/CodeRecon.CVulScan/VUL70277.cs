﻿using CodeRecon.Core;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CodeRecon.CVulScan
{
    public class VUL70277
    {
        List<string> dangMethods;
        List<CRVul> vuls;
        public VUL70277()
        {
            _init_dangMethods();
            _init_vuls();
        }

        public List<CRVul> GetVuls(CRFile file)
        {
            try
            {
 
                    //loop through dangMethods(outer loop)
                    foreach(var dm in dangMethods)
                    {
                        var lines = File.ReadAllLines(file.Path);
                        //read all lines and parse by line (inner loop)
                        for (int i = 0; i < lines.Length; i++)
                        {
                            try
                            {
                                var matches = Regex.Matches(lines[i], dm);
                                if (matches.Count > 0)
                                {
                                    //found match do something
                                    CRVul vul = new CRVul();
                                    vul.VulID = "VUL70277";
                                    vul.Line = lines[i];
                                    vul.LineNumber = i;
                                    vul.Path = file.Path;
                                    //add to list
                                    vuls.Add(vul);
                                }
                            }
                            catch (Exception ex)
                            {
                                throw new VulRecFacException("VUL70277: error parsing lines..." + ex.Message);
                            }

                        }//end (inner loop)
                    }
                //end (outer loop)
                return vuls;
                
            }
            catch (Exception ex)
            {
                throw new VulRecFacException("VUL70277: " + ex.Message);
            }
            
        }


        private void _init_dangMethods()
        {
            dangMethods = new List<string>();
            /*Banned get functions: gets, _getts, _gettws*/
            dangMethods.Add(@"gets\(");
            dangMethods.Add(@"_getts\(");
            dangMethods.Add(@"_gettws\(");
            //end banned gets functions

            /*Banned scanf functions scanf, wscanf, _tscanf,
            sscanf, swscanf, _stscanf, snscanf, snwscanf, _sntscanf*/
            dangMethods.Add(@"scanf\(");
            dangMethods.Add(@"fscanf\(");
            dangMethods.Add(@"wscanf\(");
            dangMethods.Add(@"_tscanf\(");
            dangMethods.Add(@"sscanf\(");
            dangMethods.Add(@"swscanf\(");
            dangMethods.Add(@"_stscanf\(");
            dangMethods.Add(@"snscanf\(");
            dangMethods.Add(@"snwscanf\(");
            dangMethods.Add(@"_sntscanf\(");
            //end scanf

            //Banned string copy functions
            /*strcpy, strcpyA, strcpyW, wcscpy, _tcscpy, 
            _mbscpy, StrCpy, StrCpyA, StrCpyW, lstrcpy, 
            lstrcpyA, lstrcpyW, _tccpy, _mbccpy, _ftcscpy, 
            strncpy, wcsncpy, _tcsncpy, _mbsncpy, _mbsnbcpy, 
            StrCpyN, StrCpyNA, StrCpyNW, StrNCpy, strcpynA,
            StrNCpyA, StrNCpyW, lstrcpyn, lstrcpynA, lstrcpynW*/
            dangMethods.Add(@"strcpy\(");
            dangMethods.Add(@"strcpyA\(");
            dangMethods.Add(@"strcpyW\(");
            dangMethods.Add(@"wcscpy\(");
            dangMethods.Add(@"_tcscpy\(");
            dangMethods.Add(@"_mbscpy\(");
            dangMethods.Add(@"StrCpy\(");
            dangMethods.Add(@"StrCpyA\(");
            dangMethods.Add(@"StrCpyW\(");
            dangMethods.Add(@"lstrcpy\(");
            dangMethods.Add(@"lstrcpyA\(");
            dangMethods.Add(@"lstrcpyW\(");
            dangMethods.Add(@"_tccpy\(");
            dangMethods.Add(@"_mbccpy\(");
            dangMethods.Add(@"_ftcscpy\(");
            dangMethods.Add(@"strncpy\(");
            dangMethods.Add(@"wcsncpy\(");
            dangMethods.Add(@"_tcsncpy\(");
            dangMethods.Add(@"_mbsncpy\(");
            dangMethods.Add(@"_mbsnbcpy\(");
            dangMethods.Add(@"StrCpyN\(");
            dangMethods.Add(@"StrCpyNA\(");
            dangMethods.Add(@"StrCpyNW\(");
            dangMethods.Add(@"StrNCpy\(");
            dangMethods.Add(@"strcpynA\(");
            dangMethods.Add(@"StrNCpyA\(");
            dangMethods.Add(@"StrNCpyW\(");
            dangMethods.Add(@"lstrcpyn\(");
            dangMethods.Add(@"lstrcpynA\(");
            dangMethods.Add(@"lstrcpynW\(");
            //end banned string copy functions

            //Banned sprintf functions _snwprintf, _snprintf, _sntprintf, nsprintf
            /*sprintfW, sprintfA, wsprintf, wsprintfW, wsprintfA, sprintf, swprintf, 
            _stprintf, wvsprintf, wvsprintfA, wvsprintfW, vsprintf, _vstprintf, 
            vswprintf Recommended: wnsprintf, wnsprintfA, wnsprintfW, _snwprintf, 
            snprintf, sntprintf _vsnprintf, vsnprintf, _vsnwprintf, _vsntprintf, 
            wvnsprintf, wvnsprintfA, wvnsprintfW*/
            dangMethods.Add(@"sprintf\(");
            dangMethods.Add(@"_snwprintf\(");
            dangMethods.Add(@"_snprintf\(");
            dangMethods.Add(@"_sntprintf\(");
            dangMethods.Add(@"nsprintf\(");
            dangMethods.Add(@"sprintfW\(");
            dangMethods.Add(@"sprintfA\(");
            dangMethods.Add(@"wsprintf\(");
            dangMethods.Add(@"wsprintfW\(");
            dangMethods.Add(@"wsprintfA\(");
            dangMethods.Add(@"_stprintf\(");
            dangMethods.Add(@"wvsprintf\(");
            dangMethods.Add(@"wvsprintfA\(");
            dangMethods.Add(@"wvsprintfW\(");
            dangMethods.Add(@"vsprintf\(");
            dangMethods.Add(@"_vstprintf\(");
            dangMethods.Add(@"vswprintf\(");
            dangMethods.Add(@"wnsprintf\(");
            dangMethods.Add(@"wnsprintfA\(");
            dangMethods.Add(@"wnsprintfW\(");
            dangMethods.Add(@"_snwprintf\(");
            dangMethods.Add(@"snprintf\(");
            dangMethods.Add(@"sntprintf\(");
            dangMethods.Add(@"_vsnprintf\(");
            dangMethods.Add(@"vsnprintf\(");
            dangMethods.Add(@"_vsnwprintf\(");
            dangMethods.Add(@"_vsntprintf\(");
            dangMethods.Add(@"wvnsprintf\(");
            dangMethods.Add(@"wvnsprintfA\(");
            dangMethods.Add(@"wvnsprintfW\(");
            //end banned sprintf functions

            /*strncat, wcsncat, _tcsncat, _mbsncat, _mbsnbcat, StrCatN, 
            StrCatNA, StrCatNW, StrNCat, StrNCatA, StrNCatW, lstrncat, 
            lstrcatnA, lstrcatnW, lstrcatn, _fstrncat*/
            dangMethods.Add(@"strcat\(");
            dangMethods.Add(@"strncat\(");
            dangMethods.Add(@"wcsncat\(");
            dangMethods.Add(@"_tcsncat\(");
            dangMethods.Add(@"_mbsncat\(");
            dangMethods.Add(@"_mbsnbcat\(");
            dangMethods.Add(@"StrCatN\(");
            dangMethods.Add(@"StrCatNA\(");
            dangMethods.Add(@"StrCatNW\(");
            dangMethods.Add(@"StrNCat\(");
            dangMethods.Add(@"StrNCatA\(");
            dangMethods.Add(@"StrNCatW\(");
            dangMethods.Add(@"lstrncat\(");
            dangMethods.Add(@"lstrcatnA\(");
            dangMethods.Add(@"lstrcatnW\(");
            dangMethods.Add(@"lstrcatn\(");
            dangMethods.Add(@"_fstrncat\(");
            dangMethods.Add(@"wcscat\(");
            //end banned concat functions

            /*Banned tokenizers: strtok, _tcstok, wcstok, _mbstok*/
            dangMethods.Add(@"strtok\(");
            dangMethods.Add(@"_tcstok\(");
            dangMethods.Add(@"wcstok\(");
            dangMethods.Add(@"_mbstok\(");
            //end banned tokenizers

            /*Banned make/split path functions: makepath, _tmakepath, _makepath,
            _wmakepath, _splitpath, _tsplitpath, _wsplitpath*/
            dangMethods.Add(@"makepath\(");
            dangMethods.Add(@"_tmakepath\(");
            dangMethods.Add(@"_makepath\(");
            dangMethods.Add(@"_wmakepath\(");
            dangMethods.Add(@"_splitpath\(");
            dangMethods.Add(@"_tsplitpath\(");
            dangMethods.Add(@"_wsplitpath\(");
            //end make/split path functions

            /*banned len functions: strlen, wcslen, _mbslen, _mbstrlen,
            StrLen, lstrlen*/
            dangMethods.Add(@"strlen\(");
            dangMethods.Add(@"wcslen\(");
            dangMethods.Add(@"_mbslen\(");
            dangMethods.Add(@"_mbstrlen\(");
            //end banned len functions

            

            /*Banned mem and alloc functions alloca, _alloca
            memcpy, RtlCopyMemory, CopyMemory, wmemcpy*/
            dangMethods.Add(@"memcpy\(");
            dangMethods.Add(@"RtlCopyMemory\(");
            dangMethods.Add(@"CopyMemory\(");
            dangMethods.Add(@"wmemcpy\(");
            dangMethods.Add(@"malloc\(");
            dangMethods.Add(@"alloc\(");
            dangMethods.Add(@"alloca\(");
            dangMethods.Add(@"_alloca\(");
            //end banned mem and alloc

            dangMethods.Add(@"swprintf\(");

            /*_itoa, _itow, _i64toa, _i64tow, _ui64toa, 
            _ui64tot, _ui64tow, _ultoa, _ultot, _ultow*/
            dangMethods.Add(@"_itoa\(");
            dangMethods.Add(@"_itow\(");
            dangMethods.Add(@"_i64toa\(");
            dangMethods.Add(@"_i64tow\(");
            dangMethods.Add(@"_ui64toa\(");
            dangMethods.Add(@"_ui64tot\(");
            dangMethods.Add(@"_ui64tow\(");
            dangMethods.Add(@"_ultoa\(");
            dangMethods.Add(@"_ultot\(");
            dangMethods.Add(@"_ultow\(");
            //end banned int conversion

            /*Banned misc. IsBadWritePtr, IsBadHugeWritePtr, 
            IsBadReadPtr, IsBadHugeReadPtr, IsBadCodePtr, 
            IsBadStringPtr*/
            dangMethods.Add(@"IsBadWritePtr\(");
            dangMethods.Add(@"IsBadHugeWritePtr\(");
            dangMethods.Add(@"IsBadReadPtr\(");
            dangMethods.Add(@"IsBadHugeReadPtr\(");
            dangMethods.Add(@"IsBadCodePtr\(");
            dangMethods.Add(@"IsBadStringPtr\(");
            //end band misc functions

            /*Banned OEM functions CharToOem, CharToOemA, CharToOemW,
            OemToChar, OemToCharA, OemToCharW, CharToOemBuffA,
            CharToOemBuffW*/
            dangMethods.Add(@"CharToOem\(");
            dangMethods.Add(@"CharToOemA\(");
            dangMethods.Add(@"CharToOemW\(");
            dangMethods.Add(@"OemToChar\(");
            dangMethods.Add(@"OemToCharA\(");
            dangMethods.Add(@"OemToCharW\(");
            dangMethods.Add(@"CharToOemBuffA\(");
            dangMethods.Add(@"CharToOemBuffW\(");
            //end banned OEM functions

        }
        private void _init_vuls()
        {
            vuls = new List<CRVul>();
        }
    }
}
