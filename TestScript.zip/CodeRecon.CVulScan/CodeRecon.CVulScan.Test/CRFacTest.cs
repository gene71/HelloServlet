﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CodeRecon.Core;
using System.Collections.Generic;

namespace CodeRecon.CVulScan.Test
{
    [TestClass]
    public class CRFacTest
    {
        [TestMethod]
        public void TestMethod1()
        {
            string dir = @"C:\Working\Project\MSTIC\MSTIC";

            try
            {
                CRFac crfac = new CRFac();
                List<CRFile> files = crfac.BuildCRFiles(dir);
                VulRecFac vrf = new VulRecFac();
                var vuls = vrf.GetVul(files);
               
                //foreach (CRFile f in files)
                //{
                //    Console.WriteLine(f.ToString());
                //}
                //Console.WriteLine("total files : " + files.Count);
            }
            catch (Exception ex)
            {
                throw new AssertFailedException(ex.Message);
            }

            

        }


    }
}
